package com.kgc.dao.pro;

import com.kgc.pojo.pro.SmbmsProvider;

import java.util.List;

public interface SmbmsProviderDao {
    /*查询供应商*/
    List<SmbmsProvider>findAll();
    /*供应商详情*/
    SmbmsProvider findById(Integer smbmsProvider);
    /*修改供应商*/
    int providerUpdate(SmbmsProvider smbmsProvider);
    /*删除供应商*/
    int providerDel(Integer id);
    /*查询供应商下是否存在订单*/
    List<SmbmsProvider> delFindById(Integer id);
    /*模糊查询供应商*/
    List<SmbmsProvider> findByName(SmbmsProvider smbmsProvider);
    /*添加供应商*/
    int addProvder(SmbmsProvider smbmsProvider);

}
