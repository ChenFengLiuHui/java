package com.kgc.dao.user;

import com.kgc.pojo.Rod.Role;
import com.kgc.pojo.user.SmbmsUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SmbmsUserDao {
    /*用户登录*/
    SmbmsUser selectAll(SmbmsUser user);
    /*修改用户密码*/
    int updateFindByPass(SmbmsUser user);
    /*查询所有用户*/
    List<SmbmsUser> findAll();
    /*模糊查询用户*/
    List<SmbmsUser> findByLike(@Param("username") String username, @Param("userrole") Integer userRole);
    /*查询用户角色*/
    List<Role>findRoleAll();
    /*查询指定用户id信息*/
    SmbmsUser userFindById(Integer id);
    /*修改指定用户*/
    int userModify(SmbmsUser user);
    /*添加用户*/
    int addUser(SmbmsUser user);
    /*按用户编码查询用户*/
    List<SmbmsUser> seleUserRoder(String usercode);
    /*删除用户*/
    int delUserById(Integer uid);


}