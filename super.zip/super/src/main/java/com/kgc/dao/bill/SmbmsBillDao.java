package com.kgc.dao.bill;

import com.kgc.pojo.bill.SmbmsBill;
import com.kgc.pojo.pro.SmbmsProvider;

import java.util.List;

public interface SmbmsBillDao {

    /*查询订单*/
    List<SmbmsBill>findAll();
    /*查询供应商*/
    List<SmbmsProvider>providerFind();
    /*模糊查询订单信息*/
    List<SmbmsBill>findByName_Id_pent(SmbmsBill smbmsBill);
    /*订单详情*/
    SmbmsBill findById(Integer id);
    /*删除订单*/
    int del(Integer sm);
    /*修改定的*/
    int chang(SmbmsBill smbmsBill);
    /*添加订单*/
    int add(SmbmsBill smbmsBill);

    /*List<SmbmsBill>findAll_ById(Integer id);*/

}


