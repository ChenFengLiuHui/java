package com.kgc.controller.userController;

import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.PageInfo;
import com.kgc.pojo.Rod.Role;
import com.kgc.pojo.user.SmbmsUser;
import com.kgc.service.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
/*用户页面*/
@Controller
public class UserControllerAdim {
    @Autowired
    private UserService service;
/*用户查询页面
*
* 分页
* */
    @RequestMapping("sys/user")
    public String userColler(Model model, Integer currentPage,
                             @RequestParam(required = false) String username,
                             @RequestParam(required = false) Integer userRole){
        /*获取数据进行查询*/
        List<Role> roleList= service.findRoleAll();
        /*判断页数是否合法*/
        if(null==currentPage){
            currentPage=1;
        }
        PageInfo<SmbmsUser>bypage=null;
        if(username==null){
            /*当数据为空时调用方法*/
            bypage=service.pageFind2(currentPage,6);
        }else if(username!=null||userRole!=0){
            /*当数据不为空时调用方法，可以写在同一个方法中*/
            bypage=service.pageFind(currentPage,6,username,userRole);
        }
        /*获取数据集合*/
        List<SmbmsUser> list = bypage.getList();
        /*控制页码数据*/
        if(currentPage<=1){
            /*最小页码*/
            currentPage=1;
        }else if(currentPage>=bypage.getPages()){
            /*最大页码*/
            currentPage=bypage.getPages();
        }
        /*保存数据*/
        model.addAttribute("userList",list);
        /*总条数*/
        model.addAttribute("totalCount",bypage.getTotal());
        /*总页数*/
        model.addAttribute("totalPage",bypage.getPages());
        /*当前页*/
        model.addAttribute("currentPage",currentPage);
        model.addAttribute("roleList",roleList);
        model.addAttribute("username",username);
        model.addAttribute("userRole",userRole);
        return "user/userlist";
    }

    /*用户详情页面*/
    @RequestMapping("sys/viewUser")
    public String findByAll(Integer uid,Model model){
        /*获取用户id进行查询用户详情*/
        SmbmsUser user = service.userFindById(uid);
        model.addAttribute("user",user);
        return "user/userview";
    }


    /*修改用户数据回显页面*/
    @RequestMapping("sys/modifyUser")
    public String modifyUse(Integer uid,Model model){
        /*获取用户id进行查询数据*/
        List<Role> roleList= service.findRoleAll();
        SmbmsUser user = service.userFindById(uid);
        /*获取到指定的用户数据进行保存*/
        model.addAttribute("user",  user);
        model.addAttribute("roleList",roleList);
        return "user/usermodify";
    }
    /*修改用户页面*/
    @RequestMapping("sys/modifyusersave")
    public String modiFyu(SmbmsUser user,long uid) {
        /*获取修改的数据和用户id，并且用户id进行赋值到用户对象中*/
        user.setId(uid);
        /*通过对象进行修改指定的用户信息*/
        int i = service.userModify(user);
        /*判断是否修改成功*/
        if (i != 0) {
            /*修改成功*/
            return "redirect:/sys/user";
        } else
            /*修改失败*/
            return "user/usermodify";
    }


    /*用户添加回显数据页面，可以通过ajax进行回显*/
    @RequestMapping("sys/useradd")
    public String addUser(Model model){
        /*查询角色信息*/
        List<Role> roleList= service.findRoleAll();
        /*保存数据*/
        model.addAttribute("roleList",roleList);
        return "user/useradd";
    }

   /* @RequestMapping("/sys/getrolelist")
    @ResponseBody
    public String sel(){
        HashMap<String,List<Role>>map=new HashMap<>();
        List<Role> roleList= service.findRoleAll();
        map.put("data",roleList);
        return JSONArray.toJSONString(roleList);
    }
*/

   /*添加用户的ajax验证页面*/
    @RequestMapping("sys/usercode")
    @ResponseBody
    public String userRoder(@RequestParam("userCode")String usercode){
        /*获取到用户的usercode，通过usercode进行查询是否存在用户*/
        List<SmbmsUser> users = service.seleUserRoder(usercode);
        HashMap<String ,String >map=new HashMap<>();
        /*判断查询结果是否为0*/
            if(users.size()!=0){
            /*查到结果*/
            map.put("userCode","exist");
        }
        return JSONArray.toJSONString(map);
    }
    /*添加用户实现页面*/
    @RequestMapping("/sys/saveuser")
    public String saveAddduser(SmbmsUser user){
        /*获取表单中的数据进行添加*/
        int i = service.addUser(user);
        if(i==0){
            /*添加失败*/
            return "user/useradd";
        }else
            /*添加成功*/
            return "redirect:/sys/user";
    }



    /*删除用户ajax验证页面*/
    @RequestMapping("/sys/deleteUser")
    @ResponseBody
    public String delUser(Integer uid){
        /*获取用户id，生成map集合，通过集合返回json数据*/
        HashMap<String,String>map=new HashMap<>();
        /*通过数据进行查找用户判断是否存在*/
        SmbmsUser user = service.userFindById(uid);
        if(null==user){
            map.put("delResult","notexist");
        }
        /*通过id进行删除用户*/
        int i = service.delUserById(uid);
        if(i!=0){
            /*删除成功*/
            map.put("delResult","true");
        }else {
            /*删除失败*/
            map.put("delResult", "false");
        }
        /*返回json数据*/
        return JSONArray.toJSONString(map);
    }

}
