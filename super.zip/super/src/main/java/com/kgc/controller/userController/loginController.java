package com.kgc.controller.userController;

import com.kgc.pojo.user.SmbmsUser;
import com.kgc.service.bill.LoginService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

/*用户登录页面*/
@Controller
public class loginController {

    @Resource
    private LoginService service;

    /*用户访问地址*/
    @RequestMapping("/actor")
    public String actor(){
        return "login";
    }

    /*登录页面*/
    @RequestMapping("/dologin")
    public String login(SmbmsUser user, HttpSession session, Model model){
        /*获取表单中的数据，通过信息进行查询*/
        SmbmsUser smbmsUser = service.selectAll(user);
        /*判断是否查询到数据*/
        if(smbmsUser==null){
            /*返回结果*/
            model.addAttribute("error","用户名或密码错误！");
            return "login";
        }else {
            /*保存对象到session中，这里可以进行保存一个数据（我这里后面用到的参数不同所以进行保存两会）*/
            session.setAttribute("user",user);
            session.setAttribute("user",smbmsUser);
            /*保存数据的模型中*/
            model.addAttribute("user",smbmsUser);
            return "frame";
        }
    }




}
