package com.kgc.controller.OutController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;

/*注销页面*/
@Controller
public class OutController {
    /*注销跳转*/
    @RequestMapping("/logout")
    public String logout(HttpSession session){
        /*获取会话中的数据进行注销*/
        session.invalidate();
        return "login";
    }
}
