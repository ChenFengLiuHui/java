package com.kgc.controller.userController;

import com.alibaba.fastjson.JSONArray;
import com.kgc.pojo.user.SmbmsUser;
import com.kgc.service.user.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
/*用户密码修改页面*/
@Controller
public class UserController {

    @Resource
    private UserService service;

    /*修改密码页面*/
    @RequestMapping("sys/pwdmodify")
    public String updatePass(){
        return "user/pwdmodify";
    }

    /*修改密码的ajax验证*/
    @RequestMapping("/sys/checkpwd")
    @ResponseBody
    public Object checkpwd(String oldpassword,HttpSession session){
        /*获取老密码，判断老密码是否正确*/
        SmbmsUser us = (SmbmsUser) session.getAttribute("user");

        HashMap<String,String>map=new HashMap<>();
        if (us.getUserpassword().equals(oldpassword)){
            if(null!=us.getUserpassword()&&!"".equals(us.getUserpassword())){
                map.put("result","true");
                return JSONArray.toJSONString(map);
            }else{
                map.put("result","sessionerror");
                return JSONArray.toJSONString(map);
            }
            }else if(null==oldpassword||"".equals(oldpassword)){
                map.put("result","error");
                return JSONArray.toJSONString(map);
        }else{

            map.put("result","false");
            return JSONArray.toJSONString(map);
        }

    }

    /*修改密码实现页面*/
    @RequestMapping("/sys/savepwdmodify")
    public String pwdmodify(SmbmsUser user,HttpSession session){
        /*获取表单中的数据和session中的数据*/
        SmbmsUser sm = (SmbmsUser) session.getAttribute("user");
        /*新建对象*/
        SmbmsUser users=new SmbmsUser();

        SmbmsUser user1=new SmbmsUser();
        /*对对象进行赋值，赋值赋入需要的值*/
        user1.setUsercode(sm.getUsercode());
        user1.setRnewpassword(user.getRnewpassword());
        user1.setOldpassword(user.getOldpassword());
        /*传入对象进行修改密码*/
            int find = service.updateFindByPass(user1);
            /*判断修改是否成功*/
            if(find==0){
                /*修改失败*/
                return "user/pwdmodify";
            }else {
                /*修改成功*/
                users.setUserpassword(user.getRnewpassword());
                session.setAttribute("user",users);
                return "frame";
            }
    }
}
