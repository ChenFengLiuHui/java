package com.kgc.controller.por;

import com.alibaba.fastjson.JSONArray;
import com.kgc.pojo.pro.SmbmsProvider;
import com.kgc.service.pro.providerService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
/*供应商页面*/
@Controller
public class ProviderController {

    @Resource
    private providerService providerService;

    /*供应商展示页面*/
    @RequestMapping("/sys/provider")
    public String provider(Model model){
        /*查询供应商*/
        List<SmbmsProvider> proList = providerService.findAll();
        /*保存数据*/
        model.addAttribute("proList", proList);
        return "pro/providerlist";

    }
    /*模糊查询*/
    @RequestMapping("/sys/searchbutton")
    public String searchbutton(Model model,SmbmsProvider smbmsProvider){
        /*获取页面中数据进行模糊查询*/
        List<SmbmsProvider>proList = providerService.findByName(smbmsProvider);
            /*保存数据*/
            model.addAttribute("proList",proList);
            model.addAttribute("provider",smbmsProvider);
        return "pro/providerlist";
    }


    /*删除的ajax验证*/
    @RequestMapping("/sys/delprovider")
    @ResponseBody
    public String delProvider(Integer proid){
        HashMap<String,Object>map=new HashMap<>();
        /*获取到页面中的数据进行查询该供应商是否存在该订单*/
        List<SmbmsProvider> se = providerService.delFindById(proid);
        /*存在不可删除 返回false，不存在返回true，可以删除*/
        if(se.size()==0){
            int i = providerService.providerDel(proid);
            if (i==0){
                map.put("delResult","false");
            }else{
                map.put("delResult","true");
            }
        }else{
            map.put("delResult",se.size());
        }
        /*返回json数据*/
        return JSONArray.toJSONString(map);
    }

    /*供应商详情信息页面*/
    @RequestMapping("sys/proview")
    public String findById(Integer proid,Model model){
        /*获取需要显示的供应商*/
        SmbmsProvider provider = providerService.findById(proid);
        model.addAttribute("provider",provider);
        /*将要显示的供应商回显会页面*/
        return "pro/providerview";
    }


    /*供应商修改页面*/
    @RequestMapping("sys/providermodify")
    public String providerModiFy(Integer proid,Model model){
        /*获取id，通过id获取回显数据*/
        SmbmsProvider provider = providerService.findById(proid);
        /*保存数据*/
        model.addAttribute("provider",provider);
        return "pro/providermodify";
    }
    /*修改供应商*/
    @RequestMapping("sys/providermodifysave")
    public String modiFySave(SmbmsProvider smbmsProvider){
        /*获取供应商修改的表单信息进行修改*/
        int update = providerService.providerUpdate(smbmsProvider);
        /*判断是否修改成功*/
        if(update==0){
            return "pro/providermodify";
        }else
        return "pro/providerlist";
    }


    /*添加供应商页面*/
    @RequestMapping("/sys/provideradd")
    public String addProvider(){
        return "pro/provideradd";
    }
    /*添加供应商*/
    @RequestMapping("/sys/provideraddsave")
    public String addProviderSov(SmbmsProvider smbmsProvider){
        /*获取到表单中的数据进行添加*/
        int i = providerService.addProvder(smbmsProvider);
        /*判断是否添加成功*/
        if(i==0) {
            /*添加失败*/
            return "pro/provideradd";
        }else
            /*添加成功*/
            return "redirect:/sys/provider";
    }



}
