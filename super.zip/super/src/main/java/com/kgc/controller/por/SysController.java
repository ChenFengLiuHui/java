package com.kgc.controller.por;

import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.PageInfo;
import com.kgc.pojo.bill.SmbmsBill;
import com.kgc.pojo.pro.SmbmsProvider;
import com.kgc.service.bill.BillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;

/*订单管理页面*/
@Controller
public class SysController {
    @Autowired
    private BillService billService;

    /*获取订单信息*/
    @RequestMapping("/sys/bill")
    public String bill(Model model,SmbmsBill smbmsBill, @RequestParam(required = false) Integer currentPage) {
        /*通过model保存数据到页面中
        *
        * 获取订单页面中的数据进行封装到对象中用于模糊查询
        *
        * 通过currentPage获取到当前页面的页码，进行分页查询
        * */
        if(currentPage==null){
            /*判断currentPage是否为空，是就进行赋值为第一页*/
            currentPage=1;
        }
        /*传入参数，通过分页插件进行分页查询数据，为pageinfo类型的数据*/
            PageInfo<SmbmsBill> allAndPage = billService.findAllAndPage(currentPage, 6,smbmsBill);
            /*将pageinfo转换为list集合*/
            List<SmbmsBill>billList=allAndPage.getList();
            /*判断页码是否大于最大页码，是进行赋值为最大页码*/
            if(currentPage>allAndPage.getPages()){
                currentPage=allAndPage.getPages();
            }
        /*判断页码是否<=1，是进行赋值为1*/
        if(currentPage<=1){
                currentPage=1;
            }
        /*将数据保存到页面中，通过页面的ajax进行调用数据*/
            List<SmbmsProvider> providerList = billService.providerFind();
            model.addAttribute("providerList",providerList);
            model.addAttribute("billList",billList);
            model.addAttribute("provider",smbmsBill);
            model.addAttribute("providerId",smbmsBill.getProviderId());
            /*总条数*/
            model.addAttribute("totalCount",allAndPage.getTotal());
            /*总页数*/
            model.addAttribute("totalPage",allAndPage.getPages());
            /*当前页*/
            model.addAttribute("currentPage",currentPage);
            /*返回页面*/
            return "bill/billlist";
    }

    /*查看商品详情页面*/
    @RequestMapping("/sys/billview")
    public String billView(@RequestParam("billid")Integer id,Model model){
        /*获取页面中单击出来的商品id，通过id进行查询商品的详情*/
        SmbmsBill bill = billService.findById(id);
        /*将数据保存到model中，用于页面进行使用*/
        model.addAttribute("bill",bill);
        /*返回页面*/
        return "bill/billview";
    }

    /*删除商品页面
    *
    * -------ajax验证删除页面
    *
    * */
    @RequestMapping(value = "/sys/billdel")
    @ResponseBody
    public Object del(int billid){
        /*获取页面中的id，通过id进行删除*/
        int del = billService.del(billid);
        HashMap<String,String> data =new HashMap<String,String>();
        /*判断删除是否成功，成功返回true，失败返回false*/
        if (del>0){
            data.put("delResult","true");
        }else{
            data.put("delResult","false");
        }
        /*将数据通过json的形式返回给页面*/
        return JSONArray.toJSONString(data);
    }

    /*订单修改页面
    *
    * 获取带商品id，通过id进行查询到数据返回给页面
    *
    * */
    @RequestMapping("/sys/billmodify")
    public String modify(Integer billid,Model model){
        /*通过id查询到商品信息*/
        SmbmsBill bill = billService.findById(billid);
        /*查询供应商的信息
        *
        * ----------（这里也可以通过ajax进行返回）
        *
        * */
        List<SmbmsProvider> providerList = billService.providerFind();
        /*保存数据*/
        model.addAttribute("providerList", providerList);
        model.addAttribute("bill",bill);
        /*返回页面*/
        return "bill/billmodify";
    }
    /*修改商品信息子页面*/
    @RequestMapping("/sys/dobillmodify")
    public String doModiFy(SmbmsBill smbmsBill,Model model){
        /*获取表单中的数据进行修改*/
        int chang = billService.chang(smbmsBill);
        /*通过商品id获取商品信息进行回显给页面*/
        SmbmsBill bill = billService.findById(smbmsBill.getId());
        /*保存数据*/
        model.addAttribute("bill",bill);
        /*判断是否修改成功*/
        if(chang==0){
            return "bill/billmodify";
        }else
            return "bill/billview";
    }


    /*添加商品页面*/
    @RequestMapping("/sys/billadd")
    public String add(Model model){
        /*获取商品id，通过id查询数据回显给页面*/
        List<SmbmsProvider> providerList = billService.providerFind();
        /*保存数据*/
        model.addAttribute("providerList", providerList);
        return "bill/billadd";
    }
    /*添加子页面*/
    @RequestMapping("/sys/dobilladd")
    public String doAdd(SmbmsBill smbmsBill){
        /*获取添加信息，将信息写入数据库*/
        int add = billService.add(smbmsBill);
        /*判断是添加成功*/
        if(add==0){
            /*修改失败*/
            return "bill/billadd";
        }else
            /*修改成功*/
        return "redirect:/sys/bill";
    }


}
