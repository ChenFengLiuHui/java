package com.kgc.pojo.user;

import com.alibaba.fastjson.annotation.JSONField;
import com.kgc.pojo.Rod.Role;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/*用户实体类*/
public class SmbmsUser implements Serializable {
    /**
     * 主键ID
     */
    private Long id;

    /**
     * 用户编码
     */
    private String usercode;

    /**
     * 用户名称
     */
    private String username;

    /**
     * 用户密码
     */
    private String userpassword;

    private String rnewpassword;
    private String oldpassword;



    public String getRnewpassword() {
        return rnewpassword;
    }

    public void setRnewpassword(String rnewpassword) {
        this.rnewpassword = rnewpassword;
    }

    public String getOldpassword() {
        return oldpassword;
    }

    public void setOldpassword(String oldpassword) {
        this.oldpassword = oldpassword;
    }

    /**
     * 性别（1:女、 2:男）
     */
    private Integer gender;

    /**
     * 出生日期
     */
    /*设置data输出的格式*/
    @JSONField(format  = "yyyy-MM-dd")
    /*通过字符串对date类型进行赋值*/
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthday;

    /*用户添加的属性 年龄*/
    private Integer age;

    public Integer getAge() {
        /*获取当前的系统时间*/
        Calendar  car=Calendar.getInstance();
        /*获取当前年份*/
        int y = car.get(Calendar.YEAR);
        /*获取当前月份*/
        int m= car.get(Calendar.MARCH);
        /*获取生日时间*/
        car.setTime(birthday);
        /*获取生日年份*/
        int odlY=car.get(Calendar.YEAR);
        /*获取生日月份*/
        int odlM=car.get(Calendar.MARCH);
        /*判断月份是否比出生月份大*/
        if(m-odlM>0){
            /*月份比出生月份大加1*/
            this.age=y-odlY+1;
        }
        return age;
    }

    public void setAge(Integer age) {
        this.age=age;

    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;

    }

    private Role role;

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    /**
     * 手机
     */
    private String phone;

    /**
     * 地址
     */
    private String address;

    /**
     * 用户角色（取自角色表-角色id）
     */
    private Long userrole;

    /**
     * 创建者（userId）
     */
    private Long createdby;

    /**
     * 创建时间
     */
    private Date creationdate;

    /**
     * 更新者（userId）
     */
    private Long modifyby;

    /**
     * 更新时间
     */
    /*对时间进行指定格式*/
    @JSONField(format = "yyyy-MM-dd")
    private Date modifydate;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsercode() {
        return usercode;
    }

    public void setUsercode(String usercode) {
        this.usercode = usercode;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserpassword() {
        return userpassword;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }



    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Long getUserrole() {
        return userrole;
    }

    public void setUserrole(Long userrole) {
        this.userrole = userrole;
    }

    public Long getCreatedby() {
        return createdby;
    }

    public void setCreatedby(Long createdby) {
        this.createdby = createdby;
    }

    public Date getCreationdate() {
        return creationdate;
    }

    public void setCreationdate(Date creationdate) {
        this.creationdate = creationdate;
    }

    public Long getModifyby() {
        return modifyby;
    }

    public void setModifyby(Long modifyby) {
        this.modifyby = modifyby;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }





}