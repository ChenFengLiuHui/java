package com.kgc.service.pro;

import com.kgc.dao.pro.SmbmsProviderDao;
import com.kgc.pojo.pro.SmbmsProvider;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class providerSerivceImpl implements providerService {
    @Resource
    private SmbmsProviderDao dao;

    @Override
    public List<SmbmsProvider> findAll() {
        return dao.findAll();
    }

    @Override
    public SmbmsProvider findById(Integer id) {
        return dao.findById(id);
    }

    @Override
    public int providerUpdate(SmbmsProvider smbmsProvider) {
        return dao.providerUpdate(smbmsProvider);
    }

    @Override
    public List<SmbmsProvider> findByName(SmbmsProvider smbmsProvider) {
        return dao.findByName(smbmsProvider);
    }

    @Override
    public int addProvder(SmbmsProvider smbmsProvider) {
        return dao.addProvder(smbmsProvider);
    }

    @Override
    public int providerDel(Integer id) {
        System.out.println("id 的值"+id);
        return dao.providerDel(id);
    }
    @Override
    public List<SmbmsProvider> delFindById(Integer id) {
        return dao.delFindById(id);
    }


}
