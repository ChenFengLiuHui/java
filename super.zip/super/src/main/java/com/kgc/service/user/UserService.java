package com.kgc.service.user;

import com.github.pagehelper.PageInfo;
import com.kgc.pojo.Rod.Role;
import com.kgc.pojo.user.SmbmsUser;

import java.util.List;

public interface UserService {


    /*查询用户*/
    List<SmbmsUser> findAll();
    /*查询用户角色*/
    List<Role>findRoleAll();
    /*查询指定id的用户信息*/
    SmbmsUser userFindById(Integer id);


    /*用户分页显示*/
    PageInfo<SmbmsUser> pageFind(int currenPage, int pageSize,String username,Integer userRole);
    PageInfo<SmbmsUser> pageFind2(int currenPage, int pageSize);


    /*修改用户信息*/
    int userModify(SmbmsUser user);
    /*修改用户密码*/
    int updateFindByPass(SmbmsUser user);


    /*添加用户*/
    int addUser(SmbmsUser user);
    /*查询用户角色回显给添加页面*/
    List<SmbmsUser> seleUserRoder(String usercode);


    /*删除用户*/
    int delUserById(Integer uid);



}
