package com.kgc.service.user;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.kgc.dao.user.SmbmsUserDao;
import com.kgc.pojo.Rod.Role;
import com.kgc.pojo.user.SmbmsUser;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Transactional
@Service
public class UserServiceImpl implements UserService {

    @Resource
    private SmbmsUserDao dao;


    @Override
    public int updateFindByPass(SmbmsUser user) {
        return dao.updateFindByPass(user);
    }

    @Override
    public List<SmbmsUser> findAll() {

        return dao.findAll();
    }

    @Override
    public PageInfo<SmbmsUser> pageFind(int currenPage, int pageSize,String username,Integer userRole) {
        PageHelper.startPage(currenPage,pageSize);

            List<SmbmsUser> userList = dao.findByLike(username,userRole);
            PageInfo<SmbmsUser> pageInfo=new PageInfo<>(userList);
            return pageInfo;
    }

    @Override
    public PageInfo<SmbmsUser> pageFind2(int currenPage, int pageSize) {
        PageHelper.startPage(currenPage,pageSize);
        List<SmbmsUser> userList = dao.findAll();
        PageInfo<SmbmsUser> pageInfo=new PageInfo<>(userList);
        return pageInfo;
    }

    @Override
    public List<Role> findRoleAll() {
        return dao.findRoleAll();
    }

    @Override
    public SmbmsUser userFindById(Integer id) {
        return dao.userFindById(id);
    }

    @Override
    public int userModify(SmbmsUser user) {
        return dao.userModify(user);
    }

    @Override
    public int addUser(SmbmsUser user) {
        return dao.addUser(user);
    }

    @Override
    public List<SmbmsUser> seleUserRoder(String usercode) {
        return dao.seleUserRoder(usercode);
    }

    @Override
    public int delUserById(Integer uid) {
        return dao.delUserById(uid);
    }
}
