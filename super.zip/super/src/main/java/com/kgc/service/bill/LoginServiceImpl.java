package com.kgc.service.bill;

import com.kgc.dao.user.SmbmsUserDao;
import com.kgc.pojo.user.SmbmsUser;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
@Transactional
@Service
public class LoginServiceImpl implements LoginService {
    @Resource
    private SmbmsUserDao userDao;

    @Override
    public SmbmsUser selectAll(SmbmsUser user) {
        return userDao.selectAll(user);
    }
}
