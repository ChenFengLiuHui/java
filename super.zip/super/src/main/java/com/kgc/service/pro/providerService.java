package com.kgc.service.pro;

import com.kgc.pojo.pro.SmbmsProvider;

import java.util.List;

public interface providerService {

    /*查询供应商*/
    List<SmbmsProvider> findAll();
    /*查询要删除的供应商下是否存在订单*/
    List<SmbmsProvider> delFindById(Integer id);
    /*按id查询供应商详情*/
    SmbmsProvider findById(Integer id);
    /*模糊查询供应商*/
    List<SmbmsProvider> findByName(SmbmsProvider smbmsProvider);


    /*修改供应商*/
    int providerUpdate(SmbmsProvider smbmsProvider);


    /*删除供应商*/
    int providerDel(Integer id);



    /*添加供应商*/
    int addProvder(SmbmsProvider smbmsProvider);


}
