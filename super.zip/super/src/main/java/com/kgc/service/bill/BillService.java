package com.kgc.service.bill;

import com.github.pagehelper.PageInfo;
import com.kgc.pojo.bill.SmbmsBill;
import com.kgc.pojo.pro.SmbmsProvider;

import java.util.List;

public interface BillService {


    /*查询供应商信息*/
    List<SmbmsProvider> providerFind();
    /*查询商品信息*/
    List<SmbmsBill>findAll();
    /*分页查询订单信息*/
    PageInfo<SmbmsBill> findAllAndPage(Integer currenPage,Integer pageSize,SmbmsBill smbmsBill);
    /*按id查询商品信息*/
    SmbmsBill findById(Integer id);


    /*按id删除订单信息*/
    int del(Integer sm);


    /*修改商品*/
    int chang(SmbmsBill smbmsBill);


    /*添加商品*/
    int add(SmbmsBill smbmsBill);



    /*不知在哪里用到了*/
   /* List<SmbmsBill>findAll_ById(Integer id);*/


}
