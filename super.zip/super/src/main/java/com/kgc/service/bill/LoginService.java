package com.kgc.service.bill;

import com.kgc.pojo.user.SmbmsUser;

public interface LoginService {
    /*用户登录*/
    SmbmsUser selectAll(SmbmsUser user);



}
