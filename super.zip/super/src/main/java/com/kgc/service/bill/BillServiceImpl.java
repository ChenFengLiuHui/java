package com.kgc.service.bill;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.kgc.dao.bill.SmbmsBillDao;
import com.kgc.pojo.bill.SmbmsBill;
import com.kgc.pojo.pro.SmbmsProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@Transactional
public class BillServiceImpl implements BillService {
    @Autowired
    private SmbmsBillDao smbmsBillDao;

    @Override
    public List<SmbmsBill> findAll() {
        return smbmsBillDao.findAll();
    }

    @Override
    public PageInfo<SmbmsBill> findAllAndPage(Integer currenPage,Integer pageSize,SmbmsBill smbmsBill) {
        PageHelper.startPage(currenPage,pageSize);
        System.out.println(smbmsBill+"852");
            System.out.println(smbmsBill.getProductName()+"getProductName");
        List<SmbmsBill> all = smbmsBillDao.findByName_Id_pent(smbmsBill);
        PageInfo<SmbmsBill>pageInfo=new PageInfo<>(all);
        return pageInfo;
    }


    @Override
    public List<SmbmsProvider> providerFind() {
        return smbmsBillDao.providerFind();
    }

    /*@Override
    public List<SmbmsBill> findByName_Id_pent(SmbmsBill smbmsBill) {
        return smbmsBillDao.findByName_Id_pent(smbmsBill);
    }*/

    @Override
    public SmbmsBill findById(Integer id) {
        return smbmsBillDao.findById(id);
    }

    @Override
    public int del(Integer sm) {
        return smbmsBillDao.del(sm);
    }

    /*@Override
    public List<SmbmsBill> findAll_ById(Integer id) {
        return smbmsBillDao.findAll_ById(id);
    }*/

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public int chang(SmbmsBill smbmsBill) {
        return smbmsBillDao.chang(smbmsBill);
    }

    @Override
    public int add(SmbmsBill smbmsBill) {
        return smbmsBillDao.add(smbmsBill);
    }
}
